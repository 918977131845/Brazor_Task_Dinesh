﻿using System;
using System.Collections.Generic;

namespace WebAPIBlazortask.Models
{
    public partial class Subject
    {
        public string SubjectId { get; set; }
        public string SubjectName { get; set; }
    }
}
