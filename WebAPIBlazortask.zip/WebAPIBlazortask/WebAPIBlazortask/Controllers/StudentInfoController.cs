﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Nancy.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPIBlazortask.Models;

namespace WebAPIBlazortask.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class StudentInfoController : ControllerBase
    {

        [HttpGet("GetAllStudentsInfo")]
        public IEnumerable<Student> GetAllStudentsInfo()
        {
            using (var context = new BlazortaskContext())
            {
                return context.Student.ToList();
            }
        }

        [HttpGet("GetStudentDetailsById/{id}")]
        public IEnumerable<Student> GetStudentDetailsById(int? id)
        {
            using (var context = new BlazortaskContext())
            {
                return context.Student.Where(p => p.StudentId == id).ToList();
            }
        }


        [HttpGet("GetStudentMarksByID/{id}")]
        public IEnumerable<StudentInformation> GetStudentMarksByID(int? id)
        {
            using (var context = new BlazortaskContext())
            {
                List<StudentInformation> stdList = new List<StudentInformation>();
                var selectedCollection = (from St in context.Student
                                  join Mar in context.Marks on St.StudentId equals Mar.StudentId
                                  join Sub in context.Subject on Mar.SubjectId equals Sub.SubjectId
                                  where St.StudentId == id
                                  select new 
                                  {
                                      St.StudentId,St.StudentName,St.DateOfBirth,Mar.MarkRate,Mar
                                      .SubjectId,Sub.SubjectName

                                  }).ToList();
                foreach (var student in selectedCollection)
                {
                    StudentInformation studentInformation= new StudentInformation();
                    studentInformation.StudentID = student.StudentId;
                    studentInformation.StudentName = student.StudentName;
                    studentInformation.SubjectName = student.SubjectName;
                    studentInformation.DateOfBirth = student.DateOfBirth;
                    studentInformation.MarkRate = student.MarkRate;
                    studentInformation.SubjectId = student.SubjectId;
                    stdList.Add(studentInformation);

                }

               return stdList;
            }
        }
    }
}
