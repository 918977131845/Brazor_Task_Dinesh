﻿using blazortask.Services;
using Microsoft.AspNetCore.Components;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPIBlazortask.Models;

namespace blazortask.Pages
{
    public class StudentINFOBase:ComponentBase
    {
        [Inject]
        public IStudentService StudentService { get; set; }

        public IEnumerable <Student> Students { get; set; }
        public IEnumerable<Student> Students1 { get; set; }
        public IEnumerable<StudentInformation> StudentInformations { get; set; } 
        public Student Student { get; set; }    

        protected override async Task OnInitializedAsync()
        {
            Students = (await StudentService.GetAllStudentsInfo()).ToList();
        }

        protected async Task<IEnumerable<Student>> GetStudentDetailsById(int? id)
        {
            StudentInformations = null;
           return Students1 = (await StudentService.GetStudentDetailsById(id)).ToList();
        }

        protected async Task<IEnumerable<StudentInformation>> GetStudentMarksByID(int? id)
        {
            Students1 = null;
            return StudentInformations=(await StudentService.GetStudentMarksByID(id)).ToList();
        }

    }
}
