﻿using Microsoft.AspNetCore.Components;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using WebAPIBlazortask.Models;

namespace blazortask.Services
{
    public class StudentService : IStudentService
    {
        private readonly HttpClient httpClient;
        public StudentService(HttpClient httpClient)
        {
            this.httpClient = httpClient;
        }
        public async Task<IEnumerable<Student>> GetAllStudentsInfo()
        {
            return await httpClient.GetJsonAsync<Student[]>("GetAllStudentsInfo");
        }

        public async Task<IEnumerable<Student>> GetStudentDetailsById(int? id)
        {
            return await httpClient.GetJsonAsync<Student[]>("GetStudentDetailsById/"+id);
        }

        public async Task<IEnumerable<StudentInformation>> GetStudentMarksByID(int? id)
        {
            return await httpClient.GetJsonAsync<StudentInformation[]>("GetStudentMarksByID/"+id);
        }
    }
}

