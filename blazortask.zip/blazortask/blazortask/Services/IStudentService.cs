﻿using System.Collections.Generic;
using System.Threading.Tasks;
using WebAPIBlazortask.Models;

namespace blazortask.Services
{
    public interface IStudentService
    {
        Task<IEnumerable<Student>> GetAllStudentsInfo();

        Task<IEnumerable<Student>> GetStudentDetailsById(int? id);

        Task<IEnumerable<StudentInformation>> GetStudentMarksByID(int? id);
    }
}
