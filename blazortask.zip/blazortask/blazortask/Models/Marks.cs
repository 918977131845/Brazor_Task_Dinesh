﻿using System;
using System.Collections.Generic;

namespace WebAPIBlazortask.Models
{
    public partial class Marks
    {
        public int? StudentId { get; set; }
        public string SubjectId { get; set; }
        public int? MarkRate { get; set; }
    }
}
