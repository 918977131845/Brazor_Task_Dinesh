﻿using System;

namespace WebAPIBlazortask.Models
{
    public class StudentInformation
    {
        public int? StudentID { get; set; } 
        public string StudentName { get; set; } 
        public Nullable<DateTime> DateOfBirth { get; set; } 
        public int? MarkRate { get; set; }
        public string SubjectId { get; set; }
        public string SubjectName { get; set; }
        
    }
}
